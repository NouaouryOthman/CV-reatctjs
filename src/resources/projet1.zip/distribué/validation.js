export const validerUsename = (username) => {
    return !!username && typeof username === 'string' && username.length>0;
}

export const validerPassowrd = (password) => {
    return !!password && typeof password === 'string' && password.length>0;
}