// Aller chercher les configurations de l'application
import 'dotenv/config';

// Importer les fichiers et librairies
import express, { json, urlencoded } from 'express';
import expressHandlebars from 'express-handlebars';
import session from 'express-session';
import memorystore from 'memorystore';
import helmet from 'helmet';
import compression from 'compression';
import cors from 'cors';
import passport from 'passport';
import cspOption from './csp-options.js';
import './authentification.js'
import { addUtilisateur } from './model/utilisateur.js';
import { validerPassowrd, validerUsename } from './validation.js';
import { getJeux } from './model/liste-jeux.js';

// Création du serveur
const app = express();
app.engine('handlebars', expressHandlebars());
app.set('view engine', 'handlebars');
const MemoryStore = memorystore(session);

// Ajout de middlewares
app.use(helmet(cspOption));
app.use(compression());
app.use(cors());
app.use(json());
app.use(urlencoded({ extended: false }));
app.use(session({
    cookie: { maxAge: 3600000 },
    name: process.env.npm_package_name,
    store: new MemoryStore({ checkPeriod: 3600000 }),
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static('public'));

// Routes.
app.get('/', (request, response) => {
    response.render('connexion', {
        title: 'Connexion',
        user : request.user
    });
});

app.get('/inscription', (request, response) => {
    response.render('inscription', {
        title: 'Inscription'
    });
});

app.post('/inscription', async (request, response) => {
    if (validerUsename(request.body.username) &&
        validerPassowrd(request.body.password)) {
        await addUtilisateur(request.body.username, request.body.password);
        response.sendStatus(201);
    }
    else {
        response.sendStatus(400);
    }
});

app.get('/liste', async (request, response) => {

    if (!request.user) {
        response.sendStatus(401);
    }
    else {
        response.render('liste', {
            title: 'Jeux vidéo',
            user: request.user,
            jeux: await getJeux()
        });
    }
});

app.post('/connexion', (request, response, next) => {
    passport.authenticate('local', (error, user, info) => {
        if (error) {
            next(error);
        }
        else if (!user) {
            response.status(401).json(info);
        }
        else {
            request.logIn(user, (error) => {
                if (error) {
                    next(error);
                }

                response.sendStatus(200);
            });
        }
    })(request, response, next);
});

app.post('/deconnexion', (request, response) => {
    request.logout();
    response.redirect('/');
});

// Renvoyer une erreur 404 pour les routes non définies
app.use(function (request, response) {
    // Renvoyer simplement une chaîne de caractère indiquant que la page n'existe pas
    response.status(404).send(request.originalUrl + ' not found.');
});

// Démarrage du serveur
app.listen(process.env.PORT);
console.info(`Serveurs démarré:`);
console.info(`http://localhost:${process.env.PORT}`);
